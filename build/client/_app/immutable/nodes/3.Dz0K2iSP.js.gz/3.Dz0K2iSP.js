import{L as m}from"../chunks/3.BCsQUkYL.js";export{m as component};
