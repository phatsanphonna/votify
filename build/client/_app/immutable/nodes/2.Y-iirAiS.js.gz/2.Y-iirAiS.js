import{L as m}from"../chunks/3.BHa-rLA9.js";export{m as component};
