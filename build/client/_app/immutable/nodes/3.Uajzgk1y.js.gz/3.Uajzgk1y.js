import{L as m}from"../chunks/3.ByidmuOj.js";export{m as component};
