import"../chunks/disclose-version.Bg9kRutz.js";function r(o,p){}export{r as component};
