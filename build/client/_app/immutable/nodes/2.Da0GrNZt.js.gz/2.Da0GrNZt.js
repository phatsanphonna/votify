import{L as m}from"../chunks/3.DA1ZRrwu.js";export{m as component};
