import{L as m}from"../chunks/3.deNnYaDI.js";export{m as component};
