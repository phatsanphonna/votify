import"../chunks/disclose-version.Bg9kRutz.js";import{p}from"../chunks/props.BVkS62al.js";function n(a,o){p(o,"data",8)}export{n as component};
