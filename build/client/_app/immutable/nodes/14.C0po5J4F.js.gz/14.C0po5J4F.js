import"../chunks/disclose-version.Bg9kRutz.js";import{p}from"../chunks/props.MJjq2fm6.js";function n(a,o){p(o,"data",8)}export{n as component};
