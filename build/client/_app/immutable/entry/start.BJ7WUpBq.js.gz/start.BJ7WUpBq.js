import{a as t}from"../chunks/entry.B_7kLJt4.js";export{t as start};
