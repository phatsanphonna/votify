import{a as t}from"../chunks/entry.CZN8pgHd.js";export{t as start};
