import{a as t}from"../chunks/entry.c75LEA1_.js";export{t as start};
