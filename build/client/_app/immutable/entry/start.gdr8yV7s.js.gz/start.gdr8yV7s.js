import{b as a}from"../chunks/entry.CCFkMjoS.js";export{a as start};
