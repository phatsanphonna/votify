import{a as t}from"../chunks/entry.gBbBbNaO.js";export{t as start};
