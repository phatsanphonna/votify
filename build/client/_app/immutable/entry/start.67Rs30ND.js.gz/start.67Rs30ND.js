import{a as t}from"../chunks/entry.nSn8JlnA.js";export{t as start};
