import{b as a}from"../chunks/entry.CGVyeEQ_.js";export{a as start};
